#ifndef _ROUTE_H_
#define _ROUTE_H_
#include "cppweb.h"
#include "./config.h"
using namespace cppweb;
extern Config config;
/********************************
	author:chenxuan
	date:2021/11/7
	funtion:funtion for 2.0 server add handle
*********************************/
void addHandle(HttpServer& )
{
}
#endif
